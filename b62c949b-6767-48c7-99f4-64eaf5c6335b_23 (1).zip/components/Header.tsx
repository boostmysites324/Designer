
'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function Header() {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  return (
    <header className="bg-white shadow-sm border-b border-gray-100">
      <div className="max-w-7xl mx-auto px-6">
        <div className="flex items-center justify-between h-16">
          <Link href="/" className="flex items-center space-x-3">
            <img 
              src="https://static.readdy.ai/image/3a4949fefa4bf9bdbe2344171768d602/cc3a9e171a7150c527735282ce03e081.png" 
              alt="Meet My Designers" 
              className="h-8 w-auto"
            />
          </Link>

          <nav className="hidden md:flex items-center space-x-8">
            <Link href="/" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              Home
            </Link>
            <Link href="/about-us" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              About Us
            </Link>
            <Link href="/browse-designers" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              Designers
            </Link>
            <Link href="/ai-assistant" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              AI Assistant
            </Link>
            <Link href="/how-to-use" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              How to Use
            </Link>
            <Link href="/contact-us" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              Contact Us
            </Link>
          </nav>

          <div className="hidden md:flex items-center space-x-4">
            <Link href="/login" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
              Sign In
            </Link>
            <Link href="/signup" className="bg-green-600 text-white px-6 py-2 rounded-full font-medium hover:bg-green-700 transition-colors cursor-pointer whitespace-nowrap">
              Get Started
            </Link>
          </div>

          <button 
            className="md:hidden p-2 rounded-lg hover:bg-gray-100 transition-colors cursor-pointer"
            onClick={() => setIsMenuOpen(!isMenuOpen)}
          >
            <i className={`ri-${isMenuOpen ? 'close' : 'menu'}-line text-xl`}></i>
          </button>
        </div>

        {isMenuOpen && (
          <div className="md:hidden py-4 border-t border-gray-100">
            <nav className="flex flex-col space-y-4">
              <Link href="/" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                Home
              </Link>
              <Link href="/about-us" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                About Us
              </Link>
              <Link href="/browse-designers" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                Designers
              </Link>
              <Link href="/ai-assistant" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                AI Assistant
              </Link>
              <Link href="/how-to-use" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                How to Use
              </Link>
              <Link href="/contact-us" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                Contact Us
              </Link>
              <div className="pt-4 border-t border-gray-100 flex flex-col space-y-3">
                <Link href="/login" className="text-gray-700 hover:text-green-600 font-medium transition-colors cursor-pointer">
                  Sign In
                </Link>
                <Link href="/signup" className="bg-green-600 text-white px-6 py-2 rounded-full font-medium hover:bg-green-700 transition-colors text-center cursor-pointer whitespace-nowrap">
                  Get Started
                </Link>
              </div>
            </nav>
          </div>
        )}
      </div>
    </header>
  );
}
