'use client';

import Header from '../components/Header';
import Footer from '../components/Footer';
import HeroSection from '../components/HeroSection';
import FeaturesSection from '../components/FeaturesSection';
import FeaturedDesigners from '../components/FeaturedDesigners';
import TrustSection from '../components/TrustSection';
import HowItWorks from '../components/HowItWorks';
import MobileShowcase from '../components/MobileShowcase';

export default function Home() {
  return (
    <div className="min-h-screen">
      <Header />
      <HeroSection />
      <HowItWorks />
      <MobileShowcase />
      <FeaturesSection />
      <FeaturedDesigners />
      <TrustSection />
      <Footer />
    </div>
  );
}