
'use client';

import { useState } from 'react';

export default function FilterSidebar() {
  const [priceRange, setPriceRange] = useState([0, 200]);
  const [selectedSkills, setSelectedSkills] = useState<string[]>([]);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [selectedRating, setSelectedRating] = useState<number | null>(null);
  const [isCollapsed, setIsCollapsed] = useState(false);

  const categories = [
    { name: 'UI/UX Design', count: 45, icon: 'ri-window-line' },
    { name: 'Web Design', count: 38, icon: 'ri-code-line' },
    { name: 'Mobile App Design', count: 32, icon: 'ri-smartphone-line' },
    { name: 'Brand Identity', count: 28, icon: 'ri-palette-line' },
    { name: 'Graphic Design', count: 41, icon: 'ri-image-line' },
    { name: 'Product Design', count: 25, icon: 'ri-box-3-line' },
    { name: 'Illustration', count: 19, icon: 'ri-brush-line' },
    { name: 'Animation', count: 15, icon: 'ri-play-circle-line' }
  ];

  const skills = [
    'Figma', 'Sketch', 'Adobe XD', 'Photoshop', 'Illustrator', 
    'InDesign', 'Webflow', 'Framer', 'After Effects', 'Prototyping'
  ];

  const toggleSkill = (skill: string) => {
    if (selectedSkills.includes(skill)) {
      setSelectedSkills(selectedSkills.filter(s => s !== skill));
    } else {
      setSelectedSkills([...selectedSkills, skill]);
    }
  };

  const toggleCategory = (category: string) => {
    if (selectedCategories.includes(category)) {
      setSelectedCategories(selectedCategories.filter(c => c !== category));
    } else {
      setSelectedCategories([...selectedCategories, category]);
    }
  };

  const clearAllFilters = () => {
    setPriceRange([0, 200]);
    setSelectedSkills([]);
    setSelectedCategories([]);
    setSelectedRating(null);
  };

  const hasActiveFilters = selectedSkills.length > 0 || selectedCategories.length > 0 || selectedRating !== null || priceRange[1] < 200;

  return (
    <div className="bg-white rounded-2xl shadow-sm border border-gray-200 sticky top-6 overflow-hidden">
      <div className="p-6 border-b border-gray-100">
        <div className="flex items-center justify-between">
          <h3 className="text-lg font-semibold text-gray-900 flex items-center space-x-2">
            <i className="ri-filter-3-line text-green-600"></i>
            <span>Filters</span>
          </h3>
          <button
            onClick={() => setIsCollapsed(!isCollapsed)}
            className="lg:hidden p-2 hover:bg-gray-100 rounded-lg transition-colors cursor-pointer"
          >
            <i className={`ri-arrow-${isCollapsed ? 'down' : 'up'}-s-line`}></i>
          </button>
        </div>
        {hasActiveFilters && (
          <div className="mt-3 flex items-center justify-between">
            <span className="text-sm text-green-600 font-medium">
              {selectedSkills.length + selectedCategories.length + (selectedRating ? 1 : 0)} active filters
            </span>
            <button
              onClick={clearAllFilters}
              className="text-sm text-gray-500 hover:text-gray-700 cursor-pointer"
            >
              Clear all
            </button>
          </div>
        )}
      </div>
      
      <div className={`${isCollapsed ? 'hidden' : 'block'} lg:block`}>
        <div className="p-6 space-y-8">
          <div>
            <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
              <i className="ri-money-dollar-circle-line text-green-600"></i>
              <span>Price Range (per hour)</span>
            </h4>
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <div className="bg-gray-100 px-3 py-2 rounded-lg">
                  <span className="text-sm font-medium text-gray-700">${priceRange[0]}</span>
                </div>
                <div className="bg-gray-100 px-3 py-2 rounded-lg">
                  <span className="text-sm font-medium text-gray-700">${priceRange[1]}+</span>
                </div>
              </div>
              <div className="relative">
                <input
                  type="range"
                  min="0"
                  max="200"
                  value={priceRange[1]}
                  onChange={(e) => setPriceRange([priceRange[0], parseInt(e.target.value)])}
                  className="w-full h-2 bg-gray-200 rounded-lg appearance-none cursor-pointer slider"
                  style={{
                    background: `linear-gradient(to right, #10b981 0%, #10b981 ${(priceRange[1]/200)*100}%, #e5e7eb ${(priceRange[1]/200)*100}%, #e5e7eb 100%)`
                  }}
                />
              </div>
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
              <i className="ri-grid-line text-green-600"></i>
              <span>Categories</span>
            </h4>
            <div className="space-y-3 max-h-64 overflow-y-auto">
              {categories.map((category) => (
                <label key={category.name} className="flex items-center justify-between cursor-pointer group hover:bg-gray-50 -mx-2 px-2 py-2 rounded-lg transition-colors">
                  <div className="flex items-center space-x-3">
                    <input
                      type="checkbox"
                      checked={selectedCategories.includes(category.name)}
                      onChange={() => toggleCategory(category.name)}
                      className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500"
                    />
                    <i className={`${category.icon} text-gray-400 group-hover:text-green-600 transition-colors`}></i>
                    <span className="text-sm text-gray-700 group-hover:text-gray-900">{category.name}</span>
                  </div>
                  <span className="text-xs text-gray-400 bg-gray-100 px-2 py-1 rounded-full">
                    {category.count}
                  </span>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
              <i className="ri-tools-line text-green-600"></i>
              <span>Skills</span>
            </h4>
            <div className="flex flex-wrap gap-2">
              {skills.map((skill) => (
                <button
                  key={skill}
                  onClick={() => toggleSkill(skill)}
                  className={`px-3 py-2 text-sm rounded-xl border cursor-pointer whitespace-nowrap transition-all duration-200 transform hover:scale-105 ${
                    selectedSkills.includes(skill)
                      ? 'bg-green-100 border-green-300 text-green-700 shadow-sm'
                      : 'bg-white border-gray-200 text-gray-700 hover:border-green-200 hover:bg-green-50'
                  }`}
                >
                  {skill}
                </button>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
              <i className="ri-star-line text-green-600"></i>
              <span>Rating</span>
            </h4>
            <div className="space-y-3">
              {[5, 4, 3].map((rating) => (
                <label key={rating} className="flex items-center cursor-pointer group hover:bg-gray-50 -mx-2 px-2 py-2 rounded-lg transition-colors">
                  <input
                    type="radio"
                    name="rating"
                    value={rating}
                    checked={selectedRating === rating}
                    onChange={() => setSelectedRating(rating)}
                    className="w-4 h-4 text-green-600 border-gray-300 focus:ring-green-500"
                  />
                  <div className="ml-3 flex items-center space-x-2">
                    <div className="flex items-center">
                      {[...Array(5)].map((_, i) => (
                        <i
                          key={i}
                          className={`ri-star-fill text-sm ${
                            i < rating ? 'text-yellow-400' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-sm text-gray-700 group-hover:text-gray-900">& up ({rating === 5 ? '12' : rating === 4 ? '28' : '45'} designers)</span>
                  </div>
                </label>
              ))}
            </div>
          </div>

          <div>
            <h4 className="font-medium text-gray-900 mb-4 flex items-center space-x-2">
              <i className="ri-flashlight-line text-green-600"></i>
              <span>Availability</span>
            </h4>
            <div className="space-y-3">
              <label className="flex items-center cursor-pointer group hover:bg-gray-50 -mx-2 px-2 py-2 rounded-lg transition-colors">
                <input type="checkbox" className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500" />
                <div className="ml-3 flex items-center space-x-2">
                  <div className="w-2 h-2 bg-green-400 rounded-full"></div>
                  <span className="text-sm text-gray-700 group-hover:text-gray-900">Available now</span>
                </div>
              </label>
              <label className="flex items-center cursor-pointer group hover:bg-gray-50 -mx-2 px-2 py-2 rounded-lg transition-colors">
                <input type="checkbox" className="w-4 h-4 text-green-600 border-gray-300 rounded focus:ring-green-500" />
                <span className="ml-3 text-sm text-gray-700 group-hover:text-gray-900">Online now</span>
              </label>
            </div>
          </div>
        </div>

        <div className="p-6 border-t border-gray-100 bg-gray-50">
          <button className="w-full bg-gradient-to-r from-green-600 to-green-700 text-white py-3 rounded-xl font-medium hover:from-green-700 hover:to-green-800 transition-all duration-200 cursor-pointer whitespace-nowrap transform hover:scale-105 shadow-sm">
            Apply Filters
          </button>
          {hasActiveFilters && (
            <button 
              onClick={clearAllFilters}
              className="w-full mt-3 text-gray-600 py-2 font-medium hover:text-gray-900 transition-colors cursor-pointer whitespace-nowrap"
            >
              Reset All Filters
            </button>
          )}
        </div>
      </div>
    </div>
  );
}
