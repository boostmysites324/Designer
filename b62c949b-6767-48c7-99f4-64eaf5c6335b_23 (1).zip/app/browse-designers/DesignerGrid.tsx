'use client';

import Link from 'next/link';
import { useState } from 'react';

export default function DesignerGrid() {
  const [sortBy, setSortBy] = useState('rating');
  const [showSortDropdown, setShowSortDropdown] = useState(false);
  const [likedDesigners, setLikedDesigners] = useState<number[]>([]);

  const sortOptions = [
    { value: 'rating', label: 'Highest Rated' },
    { value: 'price-low', label: 'Price: Low to High' },
    { value: 'price-high', label: 'Price: High to Low' },
    { value: 'newest', label: 'Newest' }
  ];

  const toggleLike = (designerId: number) => {
    if (likedDesigners.includes(designerId)) {
      setLikedDesigners(likedDesigners.filter(id => id !== designerId));
    } else {
      setLikedDesigners([...likedDesigners, designerId]);
    }
  };

  const designers = [
    {
      id: 1,
      name: 'Rajiv Kumar',
      specialty: 'Logo Design, Branding, Print Design',
      rating: 4.8,
      reviews: 124,
      pricePerMin: 2.0,
      bio: 'I specialize in creating memorable brands and logos with over 7 years of experience working with both startups and established businesses. My design philosophy focuses on clean, functional aesthetics that communicate your brand\'s values effectively.',
      image: 'https://readdy.ai/api/search-image?query=professional%20indian%20male%20graphic%20designer%20working%20on%20branding%20projects%2C%20modern%20office%20workspace%2C%20confident%20expression%2C%20contemporary%20style%20with%20design%20materials%20and%20color%20swatches%2C%20bright%20lighting%2C%20creative%20environment&width=400&height=400&seq=rajiv-kumar&orientation=squarish',
      skills: ['Logo Design', 'Branding', 'Print Design', 'Illustrator'],
      completedProjects: 89,
      availability: 'Available',
      location: 'Mumbai, India',
      isOnline: true,
      responseTime: '1 hour'
    },
    {
      id: 2,
      name: 'Sarah Chen',
      specialty: 'UI/UX Design, Mobile App Design',
      rating: 4.9,
      reviews: 187,
      pricePerMin: 2.3,
      bio: 'I create intuitive user experiences and beautiful interfaces for mobile and web applications. With 6+ years in the industry, I focus on user-centered design that drives engagement and conversions.',
      image: 'https://readdy.ai/api/search-image?query=professional%20female%20asian%20designer%20working%20on%20laptop%20in%20modern%20office%2C%20creative%20workspace%20with%20design%20tools%2C%20smiling%20confident%20expression%2C%20contemporary%20style%2C%20bright%20lighting%2C%20minimalist%20background%20with%20plants%20and%20design%20elements&width=400&height=400&seq=sarah-chen&orientation=squarish',
      skills: ['UI/UX Design', 'Figma', 'Prototyping', 'User Research'],
      completedProjects: 127,
      availability: 'Available',
      location: 'San Francisco, CA',
      isOnline: true,
      responseTime: '30 mins'
    },
    {
      id: 3,
      name: 'Marcus Johnson',
      specialty: 'Brand Identity, Visual Identity',
      rating: 4.7,
      reviews: 95,
      pricePerMin: 1.8,
      bio: 'Brand strategist and visual designer helping businesses build strong identities. I work with companies of all sizes to create cohesive brand experiences that resonate with their target audience.',
      image: 'https://readdy.ai/api/search-image?query=professional%20african%20american%20male%20graphic%20designer%20in%20creative%20studio%2C%20working%20on%20brand%20identity%20projects%2C%20focused%20expression%2C%20modern%20workspace%20with%20color%20swatches%20and%20design%20materials%2C%20natural%20lighting&width=400&height=400&seq=marcus-johnson&orientation=squarish',
      skills: ['Brand Strategy', 'Visual Identity', 'Illustrator', 'Photoshop'],
      completedProjects: 76,
      availability: 'Available',
      location: 'New York, NY',
      isOnline: false,
      responseTime: '2 hours'
    },
    {
      id: 4,
      name: 'Elena Rodriguez',
      specialty: 'Web Design, E-commerce Design',
      rating: 5.0,
      reviews: 156,
      pricePerMin: 2.5,
      bio: 'Passionate about creating stunning websites that convert visitors into customers. I specialize in responsive web design and e-commerce solutions that blend creativity with technical expertise.',
      image: 'https://readdy.ai/api/search-image?query=professional%20hispanic%20female%20web%20designer%20at%20computer%20workstation%2C%20multiple%20monitors%20showing%20website%20designs%2C%20creative%20office%20environment%2C%20confident%20pose%2C%20modern%20tech%20setup%20with%20design%20tools%20and%20references&width=400&height=400&seq=elena-rodriguez&orientation=squarish',
      skills: ['Web Design', 'Webflow', 'CSS', 'E-commerce'],
      completedProjects: 134,
      availability: 'Busy',
      location: 'Los Angeles, CA',
      isOnline: true,
      responseTime: '1 hour'
    },
    {
      id: 5,
      name: 'David Kim',
      specialty: 'Mobile App Design, Product Design',
      rating: 4.8,
      reviews: 112,
      pricePerMin: 2.1,
      bio: 'Product designer specializing in mobile applications and digital products. I help startups and established companies create user-friendly apps that solve real problems and delight users.',
      image: 'https://readdy.ai/api/search-image?query=professional%20asian%20male%20mobile%20app%20designer%20reviewing%20smartphone%20interfaces%2C%20modern%20office%20with%20tablet%20and%20mobile%20devices%2C%20creative%20workspace%20with%20app%20wireframes%2C%20professional%20attire%2C%20focused%20on%20mobile%20design%20work&width=400&height=400&seq=david-kim&orientation=squarish',
      skills: ['Mobile UI', 'Product Design', 'Prototyping', 'User Testing'],
      completedProjects: 98,
      availability: 'Available',
      location: 'Seattle, WA',
      isOnline: true,
      responseTime: '45 mins'
    },
    {
      id: 6,
      name: 'Isabella Torres',
      specialty: 'Graphic Design, Print Design',
      rating: 4.6,
      reviews: 89,
      pricePerMin: 1.6,
      bio: 'Creative graphic designer with expertise in print and digital media. I love bringing ideas to life through compelling visual communications that make brands stand out in crowded markets.',
      image: 'https://readdy.ai/api/search-image?query=professional%20latina%20female%20graphic%20designer%20working%20on%20creative%20projects%2C%20modern%20studio%20environment%20with%20design%20materials%2C%20focused%20on%20graphic%20design%20work%2C%20contemporary%20workspace%20with%20artistic%20elements&width=400&height=400&seq=isabella-torres&orientation=squarish',
      skills: ['Graphic Design', 'InDesign', 'Print Design', 'Typography'],
      completedProjects: 67,
      availability: 'Available',
      location: 'Miami, FL',
      isOnline: false,
      responseTime: '3 hours'
    }
  ];

  return (
    <div>
      {/* Header */}
      <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center mb-8 gap-4">
        <div className="flex items-center space-x-4">
          <p className="text-gray-600 font-medium">{designers.length} designers found</p>
          <div className="hidden sm:flex items-center space-x-2">
            <div className="w-2 h-2 bg-green-400 rounded-full animate-pulse"></div>
            <span className="text-sm text-green-600 font-medium">
              {designers.filter(d => d.isOnline).length} online now
            </span>
          </div>
        </div>
        
        <div className="flex items-center space-x-4">
          <span className="text-sm text-gray-600">Sort by:</span>
          <div className="relative">
            <button 
              onClick={() => setShowSortDropdown(!showSortDropdown)}
              className="flex items-center space-x-2 bg-white border border-gray-200 px-4 py-2 rounded-xl cursor-pointer hover:border-green-300 hover:shadow-md transition-all duration-200 min-w-[160px]"
            >
              <span className="text-sm font-medium">
                {sortOptions.find(option => option.value === sortBy)?.label}
              </span>
              <i className={`ri-arrow-down-s-line text-gray-400 transition-transform duration-200 ${showSortDropdown ? 'rotate-180' : ''}`}></i>
            </button>
            
            {showSortDropdown && (
              <div className="absolute top-full right-0 mt-2 w-48 bg-white border border-gray-200 rounded-xl shadow-lg z-10 py-2">
                {sortOptions.map((option) => (
                  <button
                    key={option.value}
                    onClick={() => {
                      setSortBy(option.value);
                      setShowSortDropdown(false);
                    }}
                    className={`w-full text-left px-4 py-2 text-sm hover:bg-gray-50 transition-colors cursor-pointer ${
                      sortBy === option.value ? 'text-green-600 font-medium bg-green-50' : 'text-gray-700'
                    }`}
                  >
                    {option.label}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </div>

      {/* Designer Cards */}
      <div className="space-y-6">
        {designers.map((designer) => (
          <div key={designer.id} className="bg-white border border-gray-200 rounded-2xl p-6 hover:shadow-lg hover:border-green-200 transition-all duration-300 group">
            <div className="flex flex-col lg:flex-row lg:items-start gap-6">
              {/* Left Side - Profile Image */}
              <div className="flex-shrink-0">
                <div className="relative">
                  <img 
                    src={designer.image} 
                    alt={designer.name}
                    className="w-20 h-20 rounded-full object-cover object-top group-hover:scale-105 transition-transform duration-300"
                  />
                  {designer.isOnline && (
                    <div className="absolute -bottom-1 -right-1 w-6 h-6 bg-green-400 rounded-full border-2 border-white flex items-center justify-center">
                      <span className="text-xs text-white font-bold">●</span>
                    </div>
                  )}
                </div>
              </div>

              {/* Middle - Designer Info */}
              <div className="flex-1 min-w-0">
                <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4">
                  <div className="flex-1">
                    <h3 className="text-xl font-semibold text-gray-900 group-hover:text-green-600 transition-colors duration-200 mb-1">
                      {designer.name}
                    </h3>
                    <p className="text-green-600 font-medium text-sm mb-2">{designer.specialty}</p>
                    
                    {/* Rating */}
                    <div className="flex items-center space-x-2 mb-3">
                      <div className="flex items-center">
                        <i className="ri-star-fill text-yellow-400 text-lg"></i>
                        <span className="text-lg font-semibold text-gray-900 ml-1">{designer.rating}</span>
                        <span className="text-sm text-gray-500 ml-1">({designer.reviews})</span>
                      </div>
                      <span className={`px-2 py-1 rounded-full text-xs font-medium ${
                        designer.isOnline 
                          ? 'bg-green-100 text-green-700' 
                          : 'bg-gray-100 text-gray-600'
                      }`}>
                        {designer.isOnline ? 'Online' : 'Offline'}
                      </span>
                    </div>

                    {/* Bio */}
                    <p className="text-gray-600 text-sm leading-relaxed mb-4">{designer.bio}</p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2">
                      {designer.skills.map((skill, index) => (
                        <span key={index} className="bg-gray-100 text-gray-700 px-3 py-1 rounded-full text-xs font-medium hover:bg-green-100 hover:text-green-700 transition-colors duration-200">
                          {skill}
                        </span>
                      ))}
                    </div>
                  </div>

                  {/* Right Side - Price and Actions */}
                  <div className="flex-shrink-0 lg:text-right">
                    <div className="text-2xl font-bold text-gray-900 mb-1">
                      ${designer.pricePerMin}<span className="text-base font-normal text-gray-500">/min</span>
                    </div>
                    <p className="text-sm text-gray-500 mb-4">Usually responds in {designer.responseTime}</p>

                    {/* Action Buttons */}
                    <div className="flex flex-col space-y-2 lg:w-48">
                      <Link href={`/designer/${designer.id}`} className="bg-green-600 text-white py-2 px-4 rounded-xl text-sm font-medium hover:bg-green-700 transition-all duration-200 cursor-pointer whitespace-nowrap text-center">
                        View Profile
                      </Link>
                      <button className="bg-white border border-green-600 text-green-600 py-2 px-4 rounded-xl text-sm font-medium hover:bg-green-50 transition-all duration-200 cursor-pointer whitespace-nowrap">
                        Chat
                      </button>
                      <button className="bg-white border border-blue-600 text-blue-600 py-2 px-4 rounded-xl text-sm font-medium hover:bg-blue-50 transition-all duration-200 cursor-pointer whitespace-nowrap">
                        Book
                      </button>
                      <button className="bg-gradient-to-r from-green-600 to-blue-600 text-white py-2 px-4 rounded-xl text-sm font-medium hover:shadow-lg transition-all duration-200 cursor-pointer whitespace-nowrap">
                        Design Session
                      </button>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>

      {/* Pagination */}
      <div className="mt-16 flex justify-center">
        <nav className="flex items-center space-x-2 bg-white rounded-2xl p-2 shadow-sm border border-gray-200">
          <button className="px-4 py-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer">
            <i className="ri-arrow-left-line"></i>
          </button>
          <button className="px-4 py-2 bg-green-600 text-white rounded-xl cursor-pointer font-medium min-w-[40px]">1</button>
          <button className="px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer min-w-[40px]">2</button>
          <button className="px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer min-w-[40px]">3</button>
          <span className="px-2 text-gray-400">...</span>
          <button className="px-4 py-2 text-gray-600 hover:text-gray-900 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer min-w-[40px]">12</button>
          <button className="px-4 py-2 text-gray-400 hover:text-gray-600 hover:bg-gray-50 rounded-xl transition-all duration-200 cursor-pointer">
            <i className="ri-arrow-right-line"></i>
          </button>
        </nav>
      </div>
    </div>
  );
}